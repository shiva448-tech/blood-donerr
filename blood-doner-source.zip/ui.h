#ifndef UI_H
#define UI_H
void ui_clear(void);
void ui_header(void);
void ui_menu(void);
void ui_pause(void);
void ui_success(const char *message);
void ui_error(const char *message);
void ui_info(const char *message);
#endif
