#include "ui.h"
#include <stdio.h>
#define R "\033[0m"
#define RED "\033[1;31m"
#define GREEN "\033[1;32m"
#define YELLOW "\033[1;33m"
#define CYAN "\033[1;36m"
#define WHITE "\033[1;37m"
#define MAGENTA "\033[1;35m"
void ui_clear(void) { printf("\033[2J\033[H"); }
void ui_header(void) {
 printf(RED "  ____  _                 _   ____                  _             \n" " | __ )| | ___   ___   __| | |  _ \\  ___  _ __   __| | ___ _ __ \n" " |  _ \\| |/ _ \\ / _ \\ / _` | | | | |/ _ \\| '_ \\ / _` |/ _ \\ '__|\n" " | |_) | | (_) | (_) | (_| | | |_| | (_) | | | | (_| |  __/ |   \n" " |____/|_|\\___/ \\___/ \\__,_| |____/ \\___/|_| |_|\\__,_|\\___|_|   \n" R);
 printf(CYAN "                 DONOR MANAGEMENT SYSTEM v1.0\n" R);
 printf(WHITE " ----------------------------------------------------------------\n" R);
}
void ui_menu(void) {
 printf(MAGENTA "\n  MAIN MENU\n" R);
 printf(CYAN "  [1] " WHITE "Register new donor\n" "  [2] Search by blood group\n" "  [3] Search by city\n" "  [4] Check donor availability\n" "  [5] Update donor details\n" "  [6] Delete donor record\n" "  [7] " RED "Emergency donor search\n" CYAN "  [8] " WHITE "Display all donors\n" "  [9] Exit\n" R);
 printf(WHITE " ----------------------------------------------------------------\n" R YELLOW "  Enter choice: " R);
}
void ui_pause(void) { char b[8]; printf(YELLOW "\n  Press ENTER to continue..." R); (void)fgets(b,sizeof b,stdin); }
void ui_success(const char *m) { printf(GREEN "\n  [SUCCESS] %s\n" R,m); }
void ui_error(const char *m) { printf(RED "\n  [ERROR] %s\n" R,m); }
void ui_info(const char *m) { printf(CYAN "\n  [INFO] %s\n" R,m); }
