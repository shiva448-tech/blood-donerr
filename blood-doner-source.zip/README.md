# 🩸 BLOOD DONOR FINDER
### A C-Based Donor Management System

A menu-driven C application for donor registration, search, availability, updates, deletion, permanent file storage, and preliminary emergency directory searches.

## Features
- Register donors with automatically generated IDs
- Search by blood group or city (city matching is case-insensitive)
- Check availability, update details, and delete records with confirmation
- Permanently store records in `donors.dat` using binary file handling
- Emergency search by exact blood group, city, and donor availability
- Colorful ANSI terminal menu
- Input validation and capacity of 1,000 donor records

## Requirements
- GCC with C11 support
- Optional: GNU Make
- Windows: MinGW-w64 GCC and Windows Terminal or VS Code terminal

## Build and run

### Linux / macOS
```bash
make
./blood_donor_finder
```

### Windows (MinGW-w64)
```powershell
gcc -std=c11 -Wall -Wextra -Wpedantic -O2 main.c donor.c storage.c ui.c -o blood_donor_finder.exe
.\blood_donor_finder.exe
```

### Any platform with GCC
```bash
gcc -std=c11 -Wall -Wextra -Wpedantic -O2 main.c donor.c storage.c ui.c -o blood_donor_finder
```

`donors.dat` is created automatically after the first successful registration. Keep it in the working directory when running the application. The file is intentionally excluded from Git.

## Project structure
```text
blood-doner/
├── main.c
├── donor.c
├── donor.h
├── storage.c
├── ui.c
├── ui.h
├── Makefile
├── .gitignore
└── README.md
```

## Donor fields
ID, full name, age, gender, blood group, city, phone number, and availability.

## Medical and privacy notice
This is an educational donor directory, not a medical decision system. Emergency search is an exact-label directory filter only; it does not establish transfusion compatibility or donor eligibility. A licensed blood bank and qualified medical professionals must verify donor identity, eligibility, ABO/Rh compatibility, screening, and crossmatching before transfusion.

Do not commit real donor personal information to a public repository. Use fictional sample data for demonstrations.

## Reference
American Society of Hematology (ASH), [Blood Basics](https://www.hematology.org/resources/patients/blood-basics).
