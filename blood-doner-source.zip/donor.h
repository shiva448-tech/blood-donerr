#ifndef DONOR_H
#define DONOR_H
#include <stddef.h>
#define MAX_DONORS 1000
#define NAME_LEN 60
#define GENDER_LEN 16
#define BLOOD_GROUP_LEN 4
#define CITY_LEN 40
#define PHONE_LEN 20
#define DATA_FILE "donors.dat"
typedef struct { int id; char name[NAME_LEN]; int age; char gender[GENDER_LEN]; char blood_group[BLOOD_GROUP_LEN]; char city[CITY_LEN]; char phone[PHONE_LEN]; int available; } Donor;
int load_donors(Donor donors[], size_t capacity);
int save_donors(const Donor donors[], size_t count);
void register_donor(Donor donors[], size_t *count);
void search_by_blood_group(const Donor donors[], size_t count);
void search_by_city(const Donor donors[], size_t count);
void check_availability(const Donor donors[], size_t count);
void update_donor(Donor donors[], size_t count);
void delete_donor(Donor donors[], size_t *count);
void emergency_search(const Donor donors[], size_t count);
void display_all_donors(const Donor donors[], size_t count);
int is_valid_blood_group(const char *group);
int next_donor_id(const Donor donors[], size_t count);
#endif
