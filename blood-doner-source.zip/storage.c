#include "donor.h"
#include <stdio.h>
int load_donors(Donor donors[], size_t capacity) {
    FILE *fp = fopen(DATA_FILE, "rb"); size_t n;
    if (!fp) return 0;
    n = fread(donors, sizeof(Donor), capacity, fp);
    if (ferror(fp)) { fclose(fp); return -1; }
    if (n == capacity) { Donor extra; if (fread(&extra, sizeof extra, 1, fp) == 1) { fclose(fp); return -2; } }
    fclose(fp); return (int)n;
}
int save_donors(const Donor donors[], size_t count) {
    FILE *fp = fopen(DATA_FILE, "wb"); size_t n;
    if (!fp) return 0;
    n = fwrite(donors, sizeof(Donor), count, fp);
    if (n != count) { fclose(fp); return 0; }
    return fclose(fp) == 0;
}
